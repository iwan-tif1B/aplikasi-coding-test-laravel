<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\master_petugas as petugas;
use Illuminate\Support\Facades\Hash;

class Auth extends Controller
{
    public function index()
    {
        return view('login');
    }

    public function checkauth(Request $request)
    {
        $username = $request->username;
        $password = $request->password;

        $AuthData = petugas::where('username',$username)->first();
        if(!$AuthData){
            return redirect('/');
        }
        if(!Hash::check($password,$AuthData->password)){
            return redirect('/');
            
        }else{
            return redirect()->route('home');
        }
    }

    function tes() {
        echo 'test'; 
    }
}

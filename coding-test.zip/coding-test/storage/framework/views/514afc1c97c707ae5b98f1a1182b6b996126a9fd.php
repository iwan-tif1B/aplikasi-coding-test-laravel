
<?php $__env->startSection('content'); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="row vh-100">
            <div class="col-sm-12 col-xl-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Data Petugas Entri</h6>
                    <a href="<?php echo e(route('m-petugas.create')); ?>" class="btn btn-primary btn-sm m-2">Tambah Petugas</a>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nama Petugas</th>
                                    <th scope="col">Jabatan</th>
                                    <th scope="col">Departemen</th>
                                    <th scope="col">Username</th>
                                    <th scope="col">Role</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($index + 1); ?></th>
                                        <td><?php echo e($rows->nama_petugas); ?></td>
                                        <td><?php echo e($rows->jabatan); ?></td>
                                        <td><?php echo e($rows->departemen); ?></td>
                                        <td><?php echo e($rows->username); ?></td>
                                        <td>
                                            <?php if($rows->role == 1): ?>
                                                <span class="badge bg-primary">Administrator</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Petugas</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm" role="group">
                                                <a href="<?php echo e(route('m-petugas.edit', $rows->id_petugas)); ?>"
                                                    class="btn btn-warning">Edit</a>
                                                <form action="<?php echo e(route('m-petugas.destroy',$rows->id_petugas)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger">Hapus</button>
                                                </form>
                                                
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coding-test\resources\views/petugas/index.blade.php ENDPATH**/ ?>
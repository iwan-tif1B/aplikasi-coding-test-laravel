
<?php $__env->startSection('content'); ?>
    <style>
        li.myitem:hover {
            background-color: #ccc;
            /* Warna latar belakang saat dihover */
            cursor: pointer;
            /* Mengubah ikon kursor menjadi tangan saat dihover */
        }
    </style>
    <div class="container-fluid pt-4 px-4">
        <div class="row ">
            <div class="col-sm-12 col-xl-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Form Tambah Data Pasien</h6>

                    <form action="<?php echo e(route('trx-registrasi.update', $regis->id_registrasi)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <fieldset>
                            <legend>Data Pasien</legend>
                            <input type="hidden" name="id_pasien" value="<?php echo e($pasien->id_pasien); ?>" id="id_pasien">
                            <div class="row mb-3">
                                <label for="no_rekam_medis" class="col-sm-2 col-form-label">No Rekam Medis</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="no_rekam_medis" name="no_rekam_medis"
                                        readonly value="<?php echo e($pasien->no_rekam_medis); ?>">
                                    <?php if($errors->first('no_rekam_medis')): ?>
                                        <small class="text-danger"> No Rekam Medis Tidak Boleh Kosong</small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="namapasien" class="col-sm-2 col-form-label">Nama Pasien</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="namapasien" name="nama_pasien"
                                        value="<?php echo e($pasien->nama_pasien); ?>" disabled>
                                    <?php if($errors->first('nama_pasien')): ?>
                                        <small class="text-danger"> nama pasien Tidak Boleh Kosong</small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="jeniskelamin" class="col-sm-2 col-form-label">Jenis Kelamin</label>
                                <div class="col-sm-10">
                                    <select name="jenis_kelamin" id="jeniskelamin" class="form-control" disabled>
                                        <option value="">Pilih Jenis Kelamin</option>
                                        <option value="laki-laki"
                                            <?php echo e($pasien->jenis_kelamin == 'laki-laki' ? 'selected' : ''); ?>>Laki Laki</option>
                                        <option value="perempuan"
                                            <?php echo e($pasien->jenis_kelamin == 'perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                                    </select>
                                    <?php if($errors->first('jenis_kelamin')): ?>
                                        <small class="text-danger"> Jenis Kelamin Tidak Boleh Kosong</small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="tanggallahir" class="col-sm-2 col-form-label">Tanggal Lahir</label>
                                <div class="col-sm-10">
                                    <input type="date" class="form-control" id="tanggallahir" name="tanggal_lahir"
                                        disabled value="<?php echo e($pasien->tanggal_lahir); ?>">
                                    <?php if($errors->first('tanggal_lahir')): ?>
                                        <small class="text-danger"> Tanggal Lahir Tidak Boleh Kosong</small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Data Registrasi Pelayanan</legend>
                            <div class="row mb-3">
                                <label for="waktu_registrasi" class="col-sm-2 col-form-label">Waktu Registrasi</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="waktu_registrasi" name="waktu_registrasi"
                                        readonly value="<?php echo e($regis->created_at); ?>">
                                    <?php if($errors->first('waktu_registrasi')): ?>
                                        <small class="text-danger"> Waktu Registrasi Tidak Boleh Kosong</small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="no_registrasi" class="col-sm-2 col-form-label">No Registasi</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="no_registrasi" name="no_registrasi"
                                        value="<?php echo e($regis->no_registrasi); ?>" readonly>
                                    <?php if($errors->first('no_registrasi')): ?>
                                        <small class="text-danger"> No Registrasi Tidak Boleh Kosong</small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="jenis_registrasi" class="col-sm-2 col-form-label">Jenis Registrasi</label>
                                <div class="col-sm-10">
                                    <select name="jenis_registrasi" class="form-control" id="">
                                        <option value="">Pilih Jenis registrasi</option>
                                        <?php $__currentLoopData = $jregis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(($regis->jenis_registrasi == $value ? 'selected':'')); ?> value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                    <?php if($errors->first('jenis_registrasi')): ?>
                                        <small class="text-danger"> Jenis Registrasi Tidak Boleh Kosong</small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="jenis_registrasi" class="col-sm-2 col-form-label">Jenis Pembayaran</label>
                                <div class="col-sm-10">
                                    <select name="jenis_pembayaran" class="form-control" id="">
                                        <option value="">Pilih Pembayaran</option>
                                        <?php $__currentLoopData = $jpembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(($regis->jenis_pembayaran == $value ? 'selected':'')); ?> value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                    <?php if($errors->first('jenis_pembayaran')): ?>
                                        <small class="text-danger"> Jenis pembayaran Tidak Boleh Kosong</small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="jenis_registrasi" class="col-sm-2 col-form-label">Status Registrasi</label>
                                <div class="col-sm-10">
                                    <select name="status_registrasi" id="" class="form-control">
                                        <option value="">Pilih Status</option>
                                        <option <?php echo e(($regis->status_registrasi == 'Aktif' ? 'selected':'')); ?> value="Aktif">Aktif</option>
                                        <option <?php echo e(($regis->status_registrasi == 'Tutup Kunjungan' ? 'selected':'')); ?> value="Tutup Kunjungan">Tutup Kunjungan</option>
                                    </select>
                                    <?php if($errors->first('jenis_registrasi')): ?>
                                        <small class="text-danger"> Status Registrasi Tidak Boleh Kosong</small>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="jenis_registrasi" class="col-sm-2 col-form-label">Jenis Pelayanan</label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="id_layanan">
                                        <option value="">Pilih Layanan</option>
                                        <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(($regis->id_layanan == $rows->id_layanan ? 'selected':'')); ?> value="<?php echo e($rows->id_layanan); ?>"><?php echo e($rows->nama_layanan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                    <?php if($errors->first('jenis_registrasi')): ?>
                                        <small class="text-danger"> Jenis Pelayanan Tidak Boleh Kosong</small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="mulai_layanan" class="col-sm-2 col-form-label">Waktu Mulai Pelayanan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="mulai_layanan"
                                        name="waktu_mulai_layanan" value="<?php echo e($regis->waktu_mulai_layanan); ?>">
                                    <?php if($errors->first('waktu_mulai_layanan')): ?>
                                        <small class="text-danger"> Waktu Mulai Layanan Tidak Boleh Kosong</small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="waktu_selesai_layanan" class="col-sm-2 col-form-label">Waktu Selesai
                                    Pelayanan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="waktu_selesai_layanan"
                                        name="waktu_selesai_layanan" value="<?php echo e($regis->waktu_selesai_layanan); ?>">
                                    <?php if($errors->first('waktu_selesai_layanan')): ?>
                                        <small class="text-danger"> Jenis Registrasi Tidak Boleh Kosong</small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </fieldset>

                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(route('trx-registrasi.index')); ?>" class="btn btn-warning">Kembali</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#mulai_layanan,#waktu_selesai_layanan').datetimepicker({
                format: 'Y-m-d H:i', // Date and time format
            });
            $('#searchInput').on('input', function() {
                let search = $(this).val();
                let results = $('#searchResults');
                if (search == '') {
                    $('#searchResults li').remove();
                    return;
                }
                $.ajax({
                    url: '<?php echo e(route('searchdata')); ?>',
                    type: 'GET',
                    data: {
                        search: search
                    },
                    success: function(data) {
                        $('#searchResults li').remove();
                        let patients = data.patients;

                        if (patients.length > 0) {
                            patients.forEach(function(patient) {
                                results.append(
                                    `<li class="list-group-item myitem additem" data-id="` +
                                    patient.id_pasien + `">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <span>No Rekam Medis : ` + patient.no_rekam_medis + ` </span><br>
                                            <span>Nama Pasien : ` + patient.nama_pasien + `</span><br>
                                            <span>Tanggal Lahir : ` + patient.tanggal_lahir + `</span>
                                        </div>
                                    </div>
                                </li>`);
                            });
                        } else {
                            results.append(`<li class="list-group-item">
                                    <button class="btn btn-primary w-100 m-2 newdata" type="button">Buat Data Pasien</button>
                                </li>`);
                        }
                    }
                });
            });

            $('#searchResults').on('click', '.newdata', function() {
                $('#namapasien,#jeniskelamin,#tanggallahir').removeAttr('disabled')
                $.ajax({
                    type: "GET",
                    url: "<?php echo e(route('norekmedis')); ?>",
                    dataType: "JSON",
                    success: function(response) {
                        console.log(response)
                        $('#searchInput').val('')
                        $('#searchResults li').remove();
                        $('#no_rekam_medis').val(response);
                        $('#id_pasien').val('0')
                    }
                });
            });

            $('#searchResults').on('click', '.additem', function() {
                let uid = $(this).data('id');

                $.ajax({
                    type: "GET",
                    url: "<?php echo e(url('DataPasien')); ?>/" + uid,
                    dataType: "JSON",
                    success: function(response) {
                        $('#id_pasien').val(response.id_pasien)
                        $('#no_rekam_medis').val(response.no_rekam_medis)
                        $('#namapasien').val(response.nama_pasien)
                        $('#jeniskelamin').val(response.jenis_kelamin)
                        $('#tanggallahir').val(response.tanggal_lahir)
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coding-test\resources\views/registrasi/edit.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
    <style>
        tr>th,
        td {
            font-size: 10px
        }

        .btn-group-sm>.btn {
            padding: 0.25rem 0.5rem;
            font-size: 12px;
            border-radius: 0.2rem;
        }
    </style>
    <div class="container-fluid pt-4 px-4">
        <div class="row vh-100">
            <div class="col-sm-12 col-xl-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Data Transaksi Pelayanan</h6>
                    <a href="<?php echo e(route('trx-registrasi.create')); ?>" class="btn btn-primary btn-sm m-2">Tambah Transaksi
                        Pelayanan</a>
                    <a href="<?php echo e(route('registrasi.print')); ?>" target="_blank" class="btn btn-primary btn-sm m-2">Print Transaksi</a>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th rowspan="2">#</th>
                                    <th rowspan="2">Waktu Registrasi</th>
                                    <th rowspan="2">No Registrasi</th>
                                    <th rowspan="2">No Rekam Medis</th>
                                    <th rowspan="2">Nama Pasien</th>
                                    <th rowspan="2">Jenis Registrasi</th>
                                    <th rowspan="2">Jenis Pembayaran</th>
                                    <th rowspan="2">Status Registrasi</th>
                                    <th rowspan="2">Jenis Layanan</th>
                                    <th colspan="2">Waktu Layanan</th>
                                    <th rowspan="2">Petugas Pendaftar</th>
                                    <th rowspan="2">Act</th>
                                </tr>
                                <tr>
                                    <th>Mulai</th>
                                    <th>Selesai</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($rows->created_at); ?></td>
                                        <td><?php echo e($rows->no_registrasi); ?></td>
                                        <td><?php echo e($rows->no_rekam_medis); ?></td>
                                        <td><?php echo e($rows->nama_pasien); ?></td>
                                        <td><?php echo e($rows->jenis_registrasi); ?></td>
                                        <td><?php echo e($rows->jenis_pembayaran); ?></td>
                                        <td><?php echo e($rows->status_registrasi); ?></td>
                                        <td><?php echo e($rows->nama_layanan); ?></td>
                                        <td><?php echo e($rows->waktu_mulai_layanan); ?></td>
                                        <td><?php echo e($rows->waktu_selesai_layanan); ?></td>
                                        <td><?php echo e($rows->nama_petugas); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('trx-registrasi.destroy', $rows->id_registrasi)); ?>"
                                                method="post">
                                                <div class="btn-group btn-group-sm" role="group">
                                                    <a href="<?php echo e(route('registrasi.closing', $rows->id_registrasi)); ?>"
                                                        class="btn btn-info">Closing</a>
                                                    <a href="<?php echo e(route('trx-registrasi.edit', $rows->id_registrasi)); ?>"
                                                        class="btn btn-warning">Edit</a>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger">Hapus</button>
                                                </div>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coding-test\resources\views/registrasi/index.blade.php ENDPATH**/ ?>
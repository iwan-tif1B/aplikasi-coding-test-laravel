
<?php $__env->startSection('content'); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="row vh-100">
            <div class="col-sm-12 col-xl-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Form Edit Data Pasien</h6>
                    <form action="<?php echo e(route('m-layanan.update',$data->id_layanan)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="row mb-3">
                            <label for="no_rekam_medis" class="col-sm-2 col-form-label">Nama Layanan</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="no_rekam_medis" name="nama_layanan"
                                     value="<?php echo e($data->nama_layanan); ?>">
                                <?php if($errors->first('nama_layanan')): ?>
                                    <small class="text-danger"> Nama Layanan Tidak Boleh Kosong</small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="namapasien" class="col-sm-2 col-form-label">Nama Pasien</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="namapasien" name="deskripsi_layanan" value="<?php echo e($data->deskripsi_layanan); ?>">
                                <?php if($errors->first('deskripsi_layanan')): ?>
                                    <small class="text-danger"> nama pasien Tidak Boleh Kosong</small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(route('m-petugas.index')); ?>" class="btn btn-warning">Kembali</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coding-test\resources\views/layanan/edit.blade.php ENDPATH**/ ?>
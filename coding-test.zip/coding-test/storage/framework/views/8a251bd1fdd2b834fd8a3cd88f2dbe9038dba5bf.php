
<?php $__env->startSection('content'); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="row vh-100">
            <div class="col-sm-12 col-xl-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Form Tambah Data Petugas</h6>
                    <form action="<?php echo e(route('m-petugas.update',$data->id_petugas)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="row mb-3">
                            <label for="nama_petugas" class="col-sm-2 col-form-label">Nama Petugas</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="nama_petugas" name="nama_petugas" value="<?php echo e($data->nama_petugas); ?>">
                                <?php if($errors->first('nama_petugas')): ?>
                                    <small class="text-danger"> Nama Petugas Tidak Boleh Kosong</small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="jabatan" class="col-sm-2 col-form-label">Jabatan</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="jabatan" name="jabatan" value="<?php echo e($data->jabatan); ?>">
                                <?php if($errors->first('jabatan')): ?>
                                    <small class="text-danger"> Jabatan Tidak Boleh Kosong</small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="departemen" class="col-sm-2 col-form-label">departemen</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="departemen" name="departemen" value="<?php echo e($data->departemen); ?>">
                                <?php if($errors->first('departemen')): ?>
                                    <small class="text-danger"> Departemen Tidak Boleh Kosong</small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="username" class="col-sm-2 col-form-label">username</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="username" name="username" value="<?php echo e($data->username); ?>">
                                <?php if($errors->first('username')): ?>
                                    <small class="text-danger"> Username Tidak Boleh Kosong</small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="passwrod" class="col-sm-2 col-form-label">passwrod</label>
                            <div class="col-sm-10">
                                <input type="password" class="form-control" id="passwrod" name="password" value="">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="passwrod" class="col-sm-2 col-form-label">Role</label>
                            <div class="col-sm-10">
                                <select name="role" id="role" class="form-control">
                                    <option value="">Pilih Role</option>
                                    <option value="1" <?php echo e(($data->role == 1 ? 'selected':'')); ?>>Admin</option>
                                    <option value="2" <?php echo e(($data->role == 2 ? 'selected':'')); ?>>Petugas</option>
                                </select>
                                <?php if($errors->first('role')): ?>
                                    <small class="text-danger"> Role Tidak Boleh Kosong</small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(route('m-petugas.index')); ?>" class="btn btn-warning">Kembali</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coding-test\resources\views/petugas/edit.blade.php ENDPATH**/ ?>
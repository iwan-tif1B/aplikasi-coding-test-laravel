
<?php $__env->startSection('content'); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="row vh-100">
            <div class="col-sm-12 col-xl-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Form Edit Data Pasien</h6>
                    <form action="<?php echo e(route('m-pasien.update',$data->id_pasien)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="row mb-3">
                            <label for="no_rekam_medis" class="col-sm-2 col-form-label">No Rekam Medis</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="no_rekam_medis" name="no_rekam_medis"
                                    readonly value="<?php echo e($data->no_rekam_medis); ?>">
                                <?php if($errors->first('no_rekam_medis')): ?>
                                    <small class="text-danger"> No Rekam Medis Tidak Boleh Kosong</small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="namapasien" class="col-sm-2 col-form-label">Nama Pasien</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="namapasien" name="nama_pasien" value="<?php echo e($data->nama_pasien); ?>">
                                <?php if($errors->first('nama_pasien')): ?>
                                    <small class="text-danger"> nama pasien Tidak Boleh Kosong</small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="jeniskelamin" class="col-sm-2 col-form-label">Jenis Kelamin</label>
                            <div class="col-sm-10">
                                <select name="jenis_kelamin" id="jeniskelamin" class="form-control">
                                    <option value="">Pilih Jenis Kelamin</option>
                                    <option value="laki-laki" <?php echo e(($data->jenis_kelamin == 'laki-laki' ? 'selected':'')); ?>>Laki Laki</option>
                                    <option value="perempuan" <?php echo e(($data->jenis_kelamin == 'perempuan' ? 'selected':'')); ?>>Perempuan</option>
                                </select>
                                <?php if($errors->first('jenis_kelamin')): ?>
                                    <small class="text-danger"> Jenis Kelamin Tidak Boleh Kosong</small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="tanggallahir" class="col-sm-2 col-form-label">Tanggal Lahir</label>
                            <div class="col-sm-10">
                                <input type="date" class="form-control" id="tanggallahir" name="tanggal_lahir" value="<?php echo e($data->tanggal_lahir); ?>">
                                <?php if($errors->first('tanggal_lahir')): ?>
                                    <small class="text-danger"> Tanggal Lahir Tidak Boleh Kosong</small>
                                <?php endif; ?>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(route('m-petugas.index')); ?>" class="btn btn-warning">Kembali</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coding-test\resources\views/pasien/edit.blade.php ENDPATH**/ ?>